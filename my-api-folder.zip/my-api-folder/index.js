const { GoogleGenerativeAI } = require("@google/generative-ai");

const express = require('express');
const cors = require('cors'); // CORS middleware
const app = express();
const port = 3000;

// Middleware
app.use(cors()); // Enable CORS
app.use(express.json()); // Parse JSON requests
const genAI = new GoogleGenerativeAI("AIzaSyDA4zR-h0BA_Idkq4bVLb8HWwY6qthUJkQ");
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
// Route to handle GET request
app.post('/', async (req, res) => {
    const prompt = req.body.prompt;
    const img = req.body.base64;
 
  try{
    if (!prompt) {
        return res.status(400).json({ error: 'Prompt is required' });
      }
      if(img){
        try{
          const cleanBase64 = img.replace(/^data:image\/\w+;base64,/, ""); // Remove extra header

        const image = {
          inlineData: {
            data: cleanBase64,
            mimeType: "image/jpeg",
          },
        };
        
        const result = await model.generateContent([{ 
          text: prompt + "\n\nIf anyone asks about you in any way, respond: 'I am RightHand AI, created by Work Fusion.'" 
      }, image]);
      
        let data = result.response.candidates[0]?.content?.parts?.[0]?.text || "No response generated";
        res.json({ res:data });
        }
        catch(e){
          console.error('Error:', e);
    res.status(500).json({ error: 'Something went wrong' });
        }
      }

else
{
    try{
      const result = await model.generateContent(prompt + "\n\nIf anyone asks about you in any way, respond: 'I am RightHand AI, created by Work Fusion.'" );
      let data = result.response.text();
      res.json({ res:data });
    }catch(e)
    {
      console.error('Error:', error);
      res.status(500).json({ e });
    }
}
  }
   catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Something went wrong' });
  }
});
// app.post('/img',async (req,res)=>{
//     let promp = req.body.urlimg;
//   const image = {
//     inlineData: {
//       data: Buffer.from(fs.readFileSync(promp)).toString("base64"),
//       mimeType: "image/png",
//     },
//   };
  
//   const result = await model.generateContent([prompt, image]);
//   console.log(result.response.text());
// })
// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});


 


 